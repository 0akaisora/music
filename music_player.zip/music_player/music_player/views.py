from django.http import JsonResponse, HttpResponse
from music_player.crawler.searchMusic import search
import json

s = search()

def index(request):
    return HttpResponse("首页")

def search(request):
    key = request.GET.get('key')
    page = request.GET.get('page')
    if(page):
        data = s.search(key, page)
    else:
        data = s.search(key)
    return HttpResponse(json.dumps(data, ensure_ascii=False), charset='utf-8')

def getMusicUrl(request):
    rid = request.GET.get('rid')
    data = s.getMusicUrl(rid)
    return HttpResponse(json.dumps(data, ensure_ascii=False), charset='utf-8')

def getList(request):
    pn = request.GET.get('pn')
    rn = request.GET.get('rn')
    id = request.GET.get('id')
    data = s.getList(pn, rn, id)
    return HttpResponse(json.dumps(data, ensure_ascii=False), charset='utf-8')

def getMList(request):
    pid = request.GET.get('pid')
    pn = request.GET.get('pn')
    rn = request.GET.get('rn')
    data = s.getMList(pid, pn, rn)
    return HttpResponse(json.dumps(data, ensure_ascii=False), charset='utf-8')

