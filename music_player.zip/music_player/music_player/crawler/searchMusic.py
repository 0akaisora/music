import requests
from bs4 import BeautifulSoup as bs
import json
import re

class search:
    headers = {
        'Host': 'www.kuwo.cn',
        'Connection': 'close',
        'Accept': 'application/json, text/plain, */*',
        'csrf': 'ZAW75UQJ3JR',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.66 Safari/537.36',
        'Referer': 'https://www.kuwo.cn/search/list',
        'Cookie': '_ga=GA1.2.2054827680.1609330372; _gid=GA1.2.1103124702.1609507711; _gat=1; Hm_lvt_cdb524f42f0ce19b169a8071123a4797=1609330372,1609507711,1609508975; Hm_lpvt_cdb524f42f0ce19b169a8071123a4797=1609508975; kw_token=ZAW75UQJ3JR'

    }
    # key = ""
    # url = ""
    # json_data = {}
    def search(self, key, page="1"):
        if(key):
            self.key = key
            self.url = "https://www.kuwo.cn/api/www/search/searchMusicBykeyWord?key=" + key + "&pn=" + page + "&rn=30&httpsStatus=1&reqId=29d06730-4c3a-11eb-bf42-33b8d9f6cdf8"
            response = requests.get(self.url, headers=self.headers)
            json_data = response.json()
            json_data = json_data['data']
            # rid = self.rid(json_data)
            # link = self.findLink(rid)
            return json_data
        else:
            return {"msg": "参数错误"}

    def getMusicUrl(self, rid):
        link = {'musicUrl': ''}
        url = 'https://www.kuwo.cn/url?format=mp3&rid=%s&response=url&type=convert_url3&br=128kmp3&from=web&t=1609597698650&httpsStatus=1&reqId=c21942b1-4d06-11eb-a291-f5cae5cc273f'%rid
        response = requests.get(url)
        json = response.json()
        if (json['url']):
            link['musicUrl'] = json['url']
        else:
            link['musicUrl'] = '参数错误'
        return link

    def getList(self, pn, rn, id):
        # str = 'https:\u002F\u002Fimg1.kuwo.cn\u002Fstar\u002Falbumcover\u002F500\u002F68\u002F84\u002F857190971.jpg'
        # str = str.encode()
        # print(str.decode('unicode_escape'))

        # url = 'https://www.kuwo.cn/api/pc/classify/playlist/getTagPlayList?pn=%s&rn=%s&id=%s&httpsStatus=1&reqId=fe5b4270-4f25-11eb-8c32-4335320f364e'%(pn, rn, id)
        url = 'http://www.kuwo.cn/api/www/classify/playlist/getTagPlayList?pn=%s&rn=%s&id=%s&httpsStatus=1&reqId=edc66c80-a2b0-11eb-aa4b-27d84eef4a1a'%(pn, rn, id)
        response = requests.get(url, headers=self.headers)
        print(response.text)
        json = response.json()
        return json

    def getMList(self, pid, pn, rn):
        url = 'https://www.kuwo.cn/api/www/playlist/playListInfo?pid=%s&pn=%s&rn=%s&httpsStatus=1&reqId=09ff8850-4e6f-11eb-bfb4-f1986b43f02f'%(pid, pn, rn)
        response = requests.get(url, headers=self.headers)
        json_data = response.json()
        return json_data



if __name__ == '__main__':
    s = search()
    s.getList(1, 30, 1265)
